compile:
make clean
make

run:
./lda.out