void inference(gsl_matrix* gamma, gsl_matrix* phi, double alpha, int docIndex,int ntopic);
